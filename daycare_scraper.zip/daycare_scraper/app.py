from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

def scrape_info(url):
    try:
        # Setting a User-Agent header to mimic a web browser
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
        }
        
        # Sending a GET request to the URL
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # Raise an error for bad responses
        
        # Parsing the HTML content
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Extracting headings (h1, h2, h3, etc.) and paragraphs
        data = {}
        data['headings'] = []
        data['paragraphs'] = []
        
        # Get all headings
        for i in range(1, 7):  # h1 to h6
            for heading in soup.find_all(f'h{i}'):
                data['headings'].append(heading.get_text(strip=True))

        # Get all paragraphs
        for paragraph in soup.find_all('p'):
            data['paragraphs'].append(paragraph.get_text(strip=True))
        
        return data

    except requests.RequestException as e:
        print(f"Request failed: {e}")
        return None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/scrape', methods=['POST'])
def scrape():
    url = request.form.get('url')
    scraped_data = scrape_info(url)

    if scraped_data:
        return render_template('result.html', data=scraped_data, url=url)
    else:
        return render_template('index.html', error="Failed to retrieve data. Please check the URL.")

if __name__ == '__main__':
    app.run(debug=True)
