from flask import Flask, render_template, request, redirect, url_for
import pandas as pd
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Configurations for file uploads
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'csv'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the uploads folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Function to read the uploaded CSV file and return a DataFrame
def read_csv_data(filepath):
    try:
        df = pd.read_csv(filepath)
        return df
    except Exception as e:
        print(f"Error reading CSV: {e}")
        return pd.DataFrame()  # Return empty DataFrame in case of failure

@app.route('/', methods=['GET', 'POST'])
def index():
    columns = None
    filtered_data = None
    df = None
    filename = None  # Initialize filename to None

    if request.method == 'POST':
        # Check if the user has uploaded a file
        if 'file' in request.files:
            file = request.files['file']
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                
                # Read CSV file
                df = read_csv_data(filepath)
                columns = df.columns.tolist()  # Get columns from CSV
                
        # Check if the form is for column filtering (filename must be in the form)
        if 'filename' in request.form:
            filename = request.form['filename']
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            df = read_csv_data(filepath)  # Reload the CSV file to apply filtering
            columns = df.columns.tolist()  # Update columns list from the uploaded file

            # If columns have been selected
            selected_columns = request.form.getlist('columns')
            if selected_columns:
                filtered_data = df[selected_columns].to_html(classes='table table-striped', index=False)

    return render_template('index.html', columns=columns, data=filtered_data, filename=filename)

if __name__ == '__main__':
    app.run(debug=True)
