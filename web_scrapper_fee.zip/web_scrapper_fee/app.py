from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin

app = Flask(__name__)

def scrape_text(url):
    """Scrape all textual content from the provided URL."""
    response = requests.get(url)
    response.raise_for_status()  # Raise an error for bad responses
    soup = BeautifulSoup(response.text, 'html.parser')

    # Extract all textual data
    text = soup.get_text(separator='\n', strip=True)
    return text

def find_links(url):
    """Find all linked URLs on the page."""
    response = requests.get(url)
    response.raise_for_status()  # Raise an error for bad responses
    soup = BeautifulSoup(response.text, 'html.parser')

    # Find all links in the document
    links = []
    for a_tag in soup.find_all('a', href=True):
        # Create absolute URLs using urljoin
        full_url = urljoin(url, a_tag['href'])
        links.append(full_url)

    return links

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        url = request.form.get('url')
        if not url:
            return render_template('home.html', error='URL is required.')

        try:
            # Scrape the main page text
            main_page_text = scrape_text(url)

            # Find all linked pages (tabs) and scrape their text
            linked_urls = find_links(url)
            scraped_texts = {}
            for link in linked_urls:
                try:
                    scraped_texts[link] = scrape_text(link)
                except Exception as e:
                    scraped_texts[link] = f"Failed to scrape: {str(e)}"

            return render_template('result.html', main_page_text=main_page_text, scraped_texts=scraped_texts)

        except requests.exceptions.RequestException as e:
            return render_template('home.html', error=str(e))

    return render_template('home.html')

if __name__ == '__main__':
    app.run(debug=True)
